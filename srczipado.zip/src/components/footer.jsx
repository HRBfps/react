function Footer(){
    return (
        <footer class="footer">Plainsboro Hospital - Hospital que tem o house.</footer>
    )
}
export default Footer;