function Header(props){
    return (
        <header class="header">{props.serie} <img src="./img/logohouse.png"></img></header>
    )
}
export default Header;